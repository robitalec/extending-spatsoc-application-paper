# spatsoc-paper-2

